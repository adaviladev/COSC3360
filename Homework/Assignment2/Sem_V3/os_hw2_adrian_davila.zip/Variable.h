//
// Created by hackeysack09 on 11/5/2016.
//

#ifndef SEM_V3_VARIABLE_H
#define SEM_V3_VARIABLE_H

#endif //SEM_V3_VARIABLE_H

#include <string>
#include <iostream>

using namespace std;

struct Variable {
	int value;
	string name;
};