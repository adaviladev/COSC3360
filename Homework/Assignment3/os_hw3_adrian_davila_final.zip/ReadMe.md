#Flags
No Special flags required to run

---
Notes:
* I was not able to figure out an implementation for Working Set, OPT or LFU with enough time due to other classes 
* The other implementations work as intended