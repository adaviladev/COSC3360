#include <iostream>

#include "Process.h"

using namespace std;

void Process::request(int, int, int){

}
void Process::useresources(int){

}
void Process::release(int, int, int){

}
void Process::calculate(int){

}