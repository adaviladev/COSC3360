#include <iostream>

using namespace std;

class Resource{
	int id;

	int nodes;
};